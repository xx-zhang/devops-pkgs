function main()
    m.log(9, "echo 123");
    return "Lua script matched.";
end
