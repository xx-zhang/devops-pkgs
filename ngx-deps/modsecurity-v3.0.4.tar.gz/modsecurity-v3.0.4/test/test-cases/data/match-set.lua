function main()
    m.log(9, "echo 123");
    m.setvar("tx.test", "whee");
    return "Lua script matched.";
end
