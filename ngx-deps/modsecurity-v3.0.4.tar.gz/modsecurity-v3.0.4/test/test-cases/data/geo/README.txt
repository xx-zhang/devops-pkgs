This data was download from:

https://github.com/maxmind/geoip-api-php/tree/master/tests

