let o = {};

export default o;

o.a = 42;
