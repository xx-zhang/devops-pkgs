Promise.resolve()
.then(() => {nonExsisting()});