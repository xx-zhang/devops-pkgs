Promise.resolve()
.finally(() => {nonExsistingInFinally()});