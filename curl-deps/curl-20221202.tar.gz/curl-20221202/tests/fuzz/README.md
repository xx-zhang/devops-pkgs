<!--
Copyright (C) 1998 - 2022 Daniel Stenberg, <daniel@haxx.se>, et al.

SPDX-License-Identifier: curl
-->

Fuzz tests
==========

The fuzzing tests for curl have been moved to [a separate
repository](https://github.com/curl/curl-fuzzer).

More information on how to get started with curl fuzz testing can be found
there.
